package com.tsystem.ticket;

import com.tsystem.exception.NotFoundException;
import com.tsystem.model.Project;
import com.tsystem.model.Ticket;
import com.tsystem.model.TicketComment;
import com.tsystem.model.TicketHistory;
import com.tsystem.model.dto.request.TicketCommentRequest;
import com.tsystem.model.dto.request.TicketCreateRequest;
import com.tsystem.model.dto.request.TicketUpdateRequest;
import com.tsystem.model.user.User;
import com.tsystem.repository.*;
import com.tsystem.service.TicketService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketServiceTest {

    @Mock TicketRepository ticketRepository;
    @Mock ProjectRepository projectRepository;
    @Mock UserRepository userRepository;
    @Mock TicketCommentRepository ticketCommentRepository;
    @Mock TicketHistoryRepository ticketHistoryRepository;

    @InjectMocks TicketService ticketService;

    private User testUser;
    private Project testProject;
    private Ticket testTicket;
    private UUID userId;
    private UUID projectId;
    private UUID ticketId;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        projectId = UUID.randomUUID();
        ticketId = UUID.randomUUID();

        testUser = User.builder()
                .id(userId)
                .username("test@example.com")
                .email("test@example.com")
                .name("Test")
                .surname("User")
                .build();

        testProject = Project.builder()
                .id(projectId)
                .name("Test Project")
                .build();

        testTicket = Ticket.builder()
                .id(ticketId)
                .name("Test Ticket")
                .description("Test Description")
                .type("BUG")
                .priority("HIGH")
                .state("OPEN")
                .project(testProject)
                .author(testUser)
                .build();
    }

    @Nested
    @DisplayName("Create Ticket Tests")
    class CreateTicketTests {

        @Test
        @DisplayName("Successfully creates ticket")
        void create_Success() {
            TicketCreateRequest req = TicketCreateRequest.builder()
                    .name("New Ticket")
                    .description("New Description")
                    .type("FEATURE")
                    .priority("MEDIUM")
                    .build();

            when(projectRepository.findById(projectId)).thenReturn(Optional.of(testProject));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> {
                Ticket t = inv.getArgument(0);
                t.setId(ticketId);
                return t;
            });

            Ticket result = ticketService.create(projectId, req, "test@example.com");

            assertEquals("New Ticket", result.getName());
            assertEquals("New Description", result.getDescription());
            assertEquals("FEATURE", result.getType());
            assertEquals("MEDIUM", result.getPriority());
            assertEquals(testProject, result.getProject());
            assertEquals(testUser, result.getAuthor());

            verify(ticketHistoryRepository).save(any(TicketHistory.class));
        }

        @Test
        @DisplayName("Create ticket logs CREATED action in history")
        void create_LogsHistory() {
            TicketCreateRequest req = TicketCreateRequest.builder()
                    .name("New Ticket")
                    .description("Description")
                    .type("BUG")
                    .priority("LOW")
                    .build();

            when(projectRepository.findById(projectId)).thenReturn(Optional.of(testProject));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> {
                Ticket t = inv.getArgument(0);
                t.setId(ticketId);
                return t;
            });

            ticketService.create(projectId, req, "test@example.com");

            ArgumentCaptor<TicketHistory> historyCaptor = ArgumentCaptor.forClass(TicketHistory.class);
            verify(ticketHistoryRepository).save(historyCaptor.capture());

            TicketHistory history = historyCaptor.getValue();
            assertEquals("CREATED", history.getAction());
            assertEquals(ticketId, history.getTicketId());
            assertEquals(userId, history.getAuthorId());
        }

        @Test
        @DisplayName("Create ticket with non-existent project throws exception")
        void create_ProjectNotFound_ThrowsException() {
            TicketCreateRequest req = TicketCreateRequest.builder()
                    .name("Ticket")
                    .description("Desc")
                    .type("BUG")
                    .priority("HIGH")
                    .build();

            when(projectRepository.findById(projectId)).thenReturn(Optional.empty());

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> ticketService.create(projectId, req, "test@example.com"));
            assertEquals("Project not found", ex.getMessage());
        }

        @Test
        @DisplayName("Create ticket with non-existent user throws exception")
        void create_UserNotFound_ThrowsException() {
            TicketCreateRequest req = TicketCreateRequest.builder()
                    .name("Ticket")
                    .description("Desc")
                    .type("BUG")
                    .priority("HIGH")
                    .build();

            when(projectRepository.findById(projectId)).thenReturn(Optional.of(testProject));
            when(userRepository.findByUsername("unknown@example.com")).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class,
                    () -> ticketService.create(projectId, req, "unknown@example.com"));
        }
    }

    @Nested
    @DisplayName("Find By Assignee Tests")
    class FindByAssigneeTests {

        @Test
        @DisplayName("Returns tickets for assignee")
        void findByAssignee_ReturnsTickets() {
            List<Ticket> tickets = Arrays.asList(testTicket);

            when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
            when(ticketRepository.findByAssigneeId(userId)).thenReturn(tickets);

            List<Ticket> result = ticketService.findByAssignee(userId);

            assertEquals(1, result.size());
            assertEquals(testTicket, result.get(0));
        }

        @Test
        @DisplayName("Returns empty list when no tickets assigned")
        void findByAssignee_ReturnsEmptyList() {
            when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
            when(ticketRepository.findByAssigneeId(userId)).thenReturn(Collections.emptyList());

            List<Ticket> result = ticketService.findByAssignee(userId);

            assertTrue(result.isEmpty());
        }

        @Test
        @DisplayName("Throws exception when user not found")
        void findByAssignee_UserNotFound_ThrowsException() {
            when(userRepository.findById(userId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class, () -> ticketService.findByAssignee(userId));
        }
    }

    @Nested
    @DisplayName("Get All By Project ID Tests")
    class GetAllByProjectIdTests {

        @Test
        @DisplayName("Returns all tickets for project")
        void getAllByProjectId_ReturnsTickets() {
            Ticket anotherTicket = Ticket.builder().id(UUID.randomUUID()).name("Another").build();
            List<Ticket> tickets = Arrays.asList(testTicket, anotherTicket);

            when(projectRepository.findById(projectId)).thenReturn(Optional.of(testProject));
            when(ticketRepository.findByProjectIdOrderByCreatedAtDesc(projectId)).thenReturn(tickets);

            List<Ticket> result = ticketService.getAllByProjectId(projectId);

            assertEquals(2, result.size());
        }

        @Test
        @DisplayName("Returns empty list when no tickets")
        void getAllByProjectId_ReturnsEmptyList() {
            when(projectRepository.findById(projectId)).thenReturn(Optional.of(testProject));
            when(ticketRepository.findByProjectIdOrderByCreatedAtDesc(projectId)).thenReturn(Collections.emptyList());

            List<Ticket> result = ticketService.getAllByProjectId(projectId);

            assertTrue(result.isEmpty());
        }

        @Test
        @DisplayName("Throws exception when project not found")
        void getAllByProjectId_ProjectNotFound_ThrowsException() {
            when(projectRepository.findById(projectId)).thenReturn(Optional.empty());

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> ticketService.getAllByProjectId(projectId));
            assertEquals("Project not found", ex.getMessage());
        }
    }

    @Nested
    @DisplayName("Get Single Ticket Tests")
    class GetTicketTests {

        @Test
        @DisplayName("Returns ticket when found")
        void get_ReturnsTicket() {
            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));

            Ticket result = ticketService.get(projectId, ticketId);

            assertEquals(testTicket, result);
        }

        @Test
        @DisplayName("Throws exception when ticket not found")
        void get_NotFound_ThrowsException() {
            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class, () -> ticketService.get(projectId, ticketId));
        }
    }

    @Nested
    @DisplayName("Update Ticket Tests")
    class UpdateTicketTests {

        @Test
        @DisplayName("Updates ticket name and logs history")
        void update_Name_LogsHistory() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Updated Name")
                    .description("Test Description")
                    .priority("HIGH")
                    .state("OPEN")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            Ticket result = ticketService.update(projectId, ticketId, req, "test@example.com");

            assertEquals("Updated Name", result.getName());
            verify(ticketHistoryRepository).save(argThat(h ->
                    "UPDATED".equals(h.getAction()) &&
                            "name".equals(h.getField()) &&
                            "Test Ticket".equals(h.getOldValue()) &&
                            "Updated Name".equals(h.getNewValue())
            ));
        }

        @Test
        @DisplayName("Updates ticket description and logs history")
        void update_Description_LogsHistory() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Test Ticket")
                    .description("Updated Description")
                    .priority("HIGH")
                    .state("OPEN")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            Ticket result = ticketService.update(projectId, ticketId, req, "test@example.com");

            assertEquals("Updated Description", result.getDescription());
            verify(ticketHistoryRepository).save(argThat(h -> "description".equals(h.getField())));
        }

        @Test
        @DisplayName("Updates ticket priority and logs history")
        void update_Priority_LogsHistory() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Test Ticket")
                    .description("Test Description")
                    .priority("LOW")
                    .state("OPEN")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            Ticket result = ticketService.update(projectId, ticketId, req, "test@example.com");

            assertEquals("LOW", result.getPriority());
            verify(ticketHistoryRepository).save(argThat(h -> "priority".equals(h.getField())));
        }

        @Test
        @DisplayName("Updates ticket state and logs history")
        void update_State_LogsHistory() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Test Ticket")
                    .description("Test Description")
                    .priority("HIGH")
                    .state("CLOSED")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            Ticket result = ticketService.update(projectId, ticketId, req, "test@example.com");

            assertEquals("CLOSED", result.getState());
            verify(ticketHistoryRepository).save(argThat(h -> "state".equals(h.getField())));
        }

        @Test
        @DisplayName("No history logged when no changes")
        void update_NoChanges_NoHistoryLogged() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Test Ticket")
                    .description("Test Description")
                    .priority("HIGH")
                    .state("OPEN")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            ticketService.update(projectId, ticketId, req, "test@example.com");

            verify(ticketHistoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Updates multiple fields and logs each change")
        void update_MultipleFields_LogsAllChanges() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("New Name")
                    .description("New Description")
                    .priority("LOW")
                    .state("IN_PROGRESS")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketRepository.save(any(Ticket.class))).thenAnswer(inv -> inv.getArgument(0));

            ticketService.update(projectId, ticketId, req, "test@example.com");

            verify(ticketHistoryRepository, times(4)).save(any(TicketHistory.class));
        }

        @Test
        @DisplayName("Throws exception when ticket not found")
        void update_TicketNotFound_ThrowsException() {
            TicketUpdateRequest req = TicketUpdateRequest.builder()
                    .name("Name")
                    .description("Desc")
                    .priority("HIGH")
                    .state("OPEN")
                    .build();

            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class,
                    () -> ticketService.update(projectId, ticketId, req, "test@example.com"));
        }
    }

    @Nested
    @DisplayName("Delete Ticket Tests")
    class DeleteTicketTests {

        @Test
        @DisplayName("Successfully deletes ticket")
        void delete_Success() {
            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));

            ticketService.delete(projectId, ticketId, "test@example.com");

            verify(ticketRepository).delete(testTicket);
        }

        @Test
        @DisplayName("Delete logs DELETED action in history")
        void delete_LogsHistory() {
            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.of(testTicket));
            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));

            ticketService.delete(projectId, ticketId, "test@example.com");

            ArgumentCaptor<TicketHistory> historyCaptor = ArgumentCaptor.forClass(TicketHistory.class);
            verify(ticketHistoryRepository).save(historyCaptor.capture());

            TicketHistory history = historyCaptor.getValue();
            assertEquals("DELETED", history.getAction());
            assertEquals(ticketId, history.getTicketId());
        }

        @Test
        @DisplayName("Throws exception when ticket not found")
        void delete_TicketNotFound_ThrowsException() {
            when(ticketRepository.findByIdAndProjectId(ticketId, projectId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class,
                    () -> ticketService.delete(projectId, ticketId, "test@example.com"));
        }
    }

    @Nested
    @DisplayName("Comment Tests")
    class CommentTests {

        private UUID commentId;
        private TicketComment testComment;

        @BeforeEach
        void setUpComments() {
            commentId = UUID.randomUUID();
            testComment = TicketComment.builder()
                    .id(commentId)
                    .ticketId(ticketId)
                    .authorId(userId)
                    .text("Test comment")
                    .build();
        }

        @Test
        @DisplayName("getComments returns all comments for ticket")
        void getComments_ReturnsComments() {
            List<TicketComment> comments = Arrays.asList(testComment);
            when(ticketCommentRepository.findByTicketIdOrderByCreatedAtAsc(ticketId)).thenReturn(comments);

            List<TicketComment> result = ticketService.getComments(ticketId);

            assertEquals(1, result.size());
            assertEquals(testComment, result.get(0));
        }

        @Test
        @DisplayName("getComments returns empty list when no comments")
        void getComments_ReturnsEmptyList() {
            when(ticketCommentRepository.findByTicketIdOrderByCreatedAtAsc(ticketId)).thenReturn(Collections.emptyList());

            List<TicketComment> result = ticketService.getComments(ticketId);

            assertTrue(result.isEmpty());
        }

        @Test
        @DisplayName("addComment creates new comment")
        void addComment_Success() {
            TicketCommentRequest req = TicketCommentRequest.builder().text("New comment").build();

            when(userRepository.findByUsername("test@example.com")).thenReturn(Optional.of(testUser));
            when(ticketCommentRepository.save(any(TicketComment.class))).thenAnswer(inv -> inv.getArgument(0));

            TicketComment result = ticketService.addComment(ticketId, req, "test@example.com");

            assertEquals(ticketId, result.getTicketId());
            assertEquals(userId, result.getAuthorId());
            assertEquals("New comment", result.getText());
        }

        @Test
        @DisplayName("addComment throws exception when user not found")
        void addComment_UserNotFound_ThrowsException() {
            TicketCommentRequest req = TicketCommentRequest.builder().text("Comment").build();

            when(userRepository.findByUsername("unknown@example.com")).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class,
                    () -> ticketService.addComment(ticketId, req, "unknown@example.com"));
        }

        @Test
        @DisplayName("updateComment updates existing comment")
        void updateComment_Success() {
            TicketCommentRequest req = TicketCommentRequest.builder().text("Updated text").build();

            when(ticketCommentRepository.findById(commentId)).thenReturn(Optional.of(testComment));
            when(ticketCommentRepository.save(any(TicketComment.class))).thenAnswer(inv -> inv.getArgument(0));

            TicketComment result = ticketService.updateComment(commentId, req);

            assertEquals("Updated text", result.getText());
        }

        @Test
        @DisplayName("updateComment throws exception when comment not found")
        void updateComment_NotFound_ThrowsException() {
            TicketCommentRequest req = TicketCommentRequest.builder().text("Text").build();

            when(ticketCommentRepository.findById(commentId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class, () -> ticketService.updateComment(commentId, req));
        }

        @Test
        @DisplayName("deleteComment deletes existing comment")
        void deleteComment_Success() {
            when(ticketCommentRepository.findById(commentId)).thenReturn(Optional.of(testComment));

            ticketService.deleteComment(commentId);

            verify(ticketCommentRepository).delete(testComment);
        }

        @Test
        @DisplayName("deleteComment throws exception when comment not found")
        void deleteComment_NotFound_ThrowsException() {
            when(ticketCommentRepository.findById(commentId)).thenReturn(Optional.empty());

            assertThrows(NotFoundException.class, () -> ticketService.deleteComment(commentId));
        }
    }

    @Nested
    @DisplayName("History Tests")
    class HistoryTests {

        @Test
        @DisplayName("getHistory returns all history entries for ticket")
        void getHistory_ReturnsHistory() {
            TicketHistory history1 = TicketHistory.builder()
                    .id(UUID.randomUUID())
                    .ticketId(ticketId)
                    .action("CREATED")
                    .createdAt(OffsetDateTime.now().minusHours(2))
                    .build();
            TicketHistory history2 = TicketHistory.builder()
                    .id(UUID.randomUUID())
                    .ticketId(ticketId)
                    .action("UPDATED")
                    .field("name")
                    .createdAt(OffsetDateTime.now())
                    .build();

            when(ticketHistoryRepository.findByTicketIdOrderByCreatedAtAsc(ticketId))
                    .thenReturn(Arrays.asList(history1, history2));

            List<TicketHistory> result = ticketService.getHistory(ticketId);

            assertEquals(2, result.size());
            assertEquals("CREATED", result.get(0).getAction());
            assertEquals("UPDATED", result.get(1).getAction());
        }

        @Test
        @DisplayName("getHistory returns empty list when no history")
        void getHistory_ReturnsEmptyList() {
            when(ticketHistoryRepository.findByTicketIdOrderByCreatedAtAsc(ticketId))
                    .thenReturn(Collections.emptyList());

            List<TicketHistory> result = ticketService.getHistory(ticketId);

            assertTrue(result.isEmpty());
        }
    }
}