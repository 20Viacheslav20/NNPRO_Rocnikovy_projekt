package com.tsystem.model.enums;

    public enum TicketState { open, in_progress, done }

