package com.tsystem.model.enums;

public enum TicketPriority {low, med, high}