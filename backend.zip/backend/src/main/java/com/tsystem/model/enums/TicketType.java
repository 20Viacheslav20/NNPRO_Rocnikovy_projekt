package com.tsystem.model.enums;

public enum TicketType { bug, feature, task }

