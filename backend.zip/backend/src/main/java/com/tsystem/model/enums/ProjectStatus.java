package com.tsystem.model.enums;

public enum ProjectStatus { ACTIVE, ARCHIVED }
